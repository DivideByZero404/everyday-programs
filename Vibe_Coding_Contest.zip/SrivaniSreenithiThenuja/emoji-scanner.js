// Unicode Emoji Scanner Script
// Scans Unicode code points up to 0x10FFFF and detects emojis using \p{Emoji}
// Generates all-emoji.txt and all-emoji.html files
// Run with: node emoji-scanner.js

const fs = require('fs');

console.log('Starting Unicode emoji scan...');

// Array to store all found emojis
const emojis = [];

// Scan Unicode code points from 0 to 0x10FFFF
for (let codePoint = 0; codePoint <= 0x10FFFF; codePoint++) {
    try {
        // Convert code point to character
        const char = String.fromCodePoint(codePoint);
        
        // Test if character is an emoji using Unicode property regex
        if (/\p{Emoji}/u.test(char)) {
            emojis.push({
                char: char,
                codePoint: codePoint.toString(16).toUpperCase().padStart(4, '0'),
                decimal: codePoint
            });
        }
    } catch (error) {
        // Skip invalid code points
        continue;
    }
    
    // Progress indicator every 10000 code points
    if (codePoint % 10000 === 0) {
        console.log(`Scanned: ${codePoint.toString(16).toUpperCase()}`);
    }
}

console.log(`Found ${emojis.length} emojis`);

// Generate all-emoji.txt file
const txtContent = emojis.map(emoji => 
    `${emoji.char} U+${emoji.codePoint} (${emoji.decimal})`
).join('\n');

fs.writeFileSync('all-emoji.txt', txtContent, 'utf8');
console.log('Generated all-emoji.txt');

// Generate all-emoji.html file
const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Unicode Emojis</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .emoji-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(60px, 1fr)); gap: 10px; }
        .emoji-item { text-align: center; padding: 10px; border: 1px solid #ddd; border-radius: 5px; }
        .emoji { font-size: 24px; }
        .code { font-size: 10px; color: #666; }
        h1 { text-align: center; }
        .count { text-align: center; margin: 20px 0; font-weight: bold; }
    </style>
</head>
<body>
    <h1>🌟 All Unicode Emojis 🌟</h1>
    <div class="count">Total: ${emojis.length} emojis</div>
    <div class="emoji-grid">
        ${emojis.map(emoji => `
        <div class="emoji-item">
            <div class="emoji">${emoji.char}</div>
            <div class="code">U+${emoji.codePoint}</div>
        </div>`).join('')}
    </div>
</body>
</html>`;

fs.writeFileSync('all-emoji.html', htmlContent, 'utf8');
console.log('Generated all-emoji.html');

console.log('Scan complete!');